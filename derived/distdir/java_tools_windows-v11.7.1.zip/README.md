This Java tools version was built from the bazel repository at commit hash 190533739ce4457cd5a3b31573fc2ae66f92d53e
using bazel version 5.1.1 on platform windows.
To build from source the same zip run the commands:

$ git clone https://github.com/bazelbuild/bazel.git
$ git checkout 190533739ce4457cd5a3b31573fc2ae66f92d53e
$ bazel build //src:java_tools_prebuilt.zip
