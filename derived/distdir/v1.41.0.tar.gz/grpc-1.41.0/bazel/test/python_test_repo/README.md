## Bazel Workspace Test

This directory houses a test ensuring that downstream projects can use
`@com_github_grpc_grpc//src/python/grpcio:grpcio`, `py_proto_library`, and
`py_grpc_library`.
