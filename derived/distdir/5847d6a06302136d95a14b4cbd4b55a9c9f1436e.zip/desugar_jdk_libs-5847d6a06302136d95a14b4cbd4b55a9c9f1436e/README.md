# desugar_jdk_libs

This project contains a small subset of OpenJDK libraries simplified for use on
older runtimes.

This is not an official Google product.

Please file bugs and feature requests in the [Android Issue Tracker, Dexer (D8)
component](https://issuetracker.google.com/issues/new?component=317603&template=1018721)
and include `[library desugar]` in the title.
